import { io, ManagerOptions, SocketOptions } from 'socket.io-client';
import {
  backendUrl,
  logging,
  SessionLayout,
  sessionBasedToken,
  socketActivityBroadcaster,
  locationProviderEnabled,
  loginPageUrl,
} from "config";
import notify from "src/_functions/notify";
import { useSocketStatus } from "../_providers/socketStatusProvider";
import { useEffect, useRef } from "react";
import { initSyncRequest, useSyncEventTrigger } from "./syncRequest";
import type { SyncRouteStreamEvent } from "./syncRequest";
import { flushApiQueue, flushSyncQueue, isOnline } from "./offlineQueue";
import {
  buildGetJoinedRoomsResponseEventName,
  buildJoinRoomResponseEventName,
  buildLeaveRoomResponseEventName,
  socketEventNames,
} from "../../shared/socketEvents";

interface SyncEventPayload {
  cb?: string;
  clientOutput?: unknown;
  serverOutput?: unknown;
  message?: string;
  status?: 'success' | 'error' | 'stream';
  fullName?: string;
  errorCode?: string;
  errorParams?: { key: string; value: string | number | boolean }[];
  httpStatus?: number;
  [key: string]: unknown;
}

const normalizeSyncRouteKey = (value: string): string => {
  const sanitized = value.replaceAll(/^\/+|\/+$/g, '');
  if (sanitized.length === 0) return '';
  if (sanitized.startsWith('sync/')) return sanitized;
  return `sync/${sanitized}`;
};

const getSyncRouteKeys = ({
  fullName,
  cb,
}: {
  fullName?: string;
  cb?: string;
}) => {
  const keys = new Set<string>();

  if (typeof fullName === 'string') {
    const normalized = normalizeSyncRouteKey(fullName);
    if (normalized) {
      keys.add(normalized);
    }
  }

  if (typeof cb === 'string') {
    const normalized = normalizeSyncRouteKey(cb);
    if (normalized) {
      keys.add(normalized);
    }
  }

  return [...keys];
};

const setDisconnectedStatus = (setSocketStatus: ReturnType<typeof useSocketStatus>["setSocketStatus"]) => {
  setSocketStatus(prev => ({
    ...prev,
    self: {
      status: "DISCONNECTED",
      reconnectAttempt: undefined,
      endTime: undefined,
    }
  }));
};

const isLocationProviderEnabled: boolean = locationProviderEnabled;
const shouldLogDev = logging.devLogs;
const shouldNotifyDev = logging.devNotifications;
const shouldLogSocketStatus = logging.socketStatus;
const shouldLogStream = logging.stream;

// Socket state (`socket`, `incrementResponseIndex`, `waitForSocket`) now
// lives in @luckystack/core/socketState — single source of truth shared with
// `apiRequest` (core) and `syncRequest` (sync). This React hook is the only
// place that assigns the socket via `setSocket(io(...))`. Re-exported below
// so existing callers that still import these symbols from this file keep
// working.
import { socket, setSocket, incrementResponseIndex, waitForSocket } from '../../packages/core/src/socketState';
// eslint-disable-next-line unicorn/prefer-export-from
export { socket, incrementResponseIndex, waitForSocket };

export function useSocket(session: SessionLayout | null) {
  const { socketStatus, setSocketStatus } = useSocketStatus();
  const { triggerSyncEvent, triggerSyncStreamEvent } = useSyncEventTrigger();
  const sessionRef = useRef(session);
  const socketStatusRef = useRef(socketStatus);

  useEffect(() => {
    sessionRef.current = session;
  }, [session])

  useEffect(() => {
    socketStatusRef.current = socketStatus;
  }, [socketStatus]);

  useEffect(() => {
    const socketOptions: Partial<ManagerOptions & SocketOptions> = {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: Infinity,
      autoConnect: true,
      withCredentials: true,
      auth: {}
    };

    if (sessionBasedToken) {
      const token = sessionStorage.getItem("token");
      if (token) {
        socketOptions.auth = { token };
      }
    }

    const socketConnection = io(backendUrl, socketOptions);
    setSocket(socketConnection);

    const canFlushQueue = () => socketConnection.connected && isOnline();

    const handleVisibility = () => {
      if (!socketActivityBroadcaster) { return; }

      if (shouldLogSocketStatus) {
        console.log(document.visibilityState);
      }

      //? user switched tab or navigated away
      if (document.visibilityState === "hidden") {
        socketConnection.emit(socketEventNames.intentionalDisconnect);

        //? user switched back to the tab
      } else {
        if (socketStatusRef.current.self.status !== "CONNECTED") {
          socketConnection.connect();
        }
        socketConnection.emit(socketEventNames.intentionalReconnect);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    if (socketActivityBroadcaster) {
      void initSyncRequest({
        setSocketStatus,
        sessionRef,
      });
    } else {
      socketConnection.on(socketEventNames.connect, () => {
        if (shouldLogSocketStatus) {
          console.log("Connected to server");
        }
      });

      socketConnection.on(socketEventNames.disconnect, () => {
        if (shouldLogSocketStatus) {
          console.log("Disconnected, trying to reconnect...");
        }
      });

      socketConnection.on(socketEventNames.reconnectAttempt, (attempt) => {
        if (shouldLogSocketStatus) {
          console.log("Reconnecting attempt", attempt);
        }
      });

      socketConnection.on(socketEventNames.connectError, (err: { message: string }) => {
        if (shouldLogDev) {
          console.error(`Connection error: ${err.message}`);
        }
        if (shouldNotifyDev) {
          notify.error({ key: 'common.connectionError' });
        }
      });
    }

    socketConnection.on(socketEventNames.connect, () => {
      flushApiQueue(canFlushQueue, socketConnection);
      flushSyncQueue(canFlushQueue, socketConnection);
    });

    socketConnection.on(socketEventNames.logout, (status: "success" | "error") => {
      if (status === "success") {
        if (sessionBasedToken) {
          sessionStorage.clear();
        }
        globalThis.location.href = loginPageUrl;
      } else {
        console.error("Logout failed");
        notify.error({ key: 'common.logoutFailed' });
      }
    });

    socketConnection.on(socketEventNames.sync, (payload: SyncEventPayload) => {
      const { cb, clientOutput, serverOutput, message, status, fullName, errorCode, errorParams } = payload;
      if (shouldLogDev) {
        console.log("Server Sync Response:", payload);
      }

      const routeKeys = getSyncRouteKeys({ fullName, cb });

      if (status === "stream") {
        if (routeKeys.length === 0) {
          return;
        }

        const streamPayload = { ...payload };
        delete streamPayload.status;
        delete streamPayload.fullName;
        delete streamPayload.cb;

        if (shouldLogStream) {
          console.log("Server Sync Stream:", { routeKeys, streamPayload });
        }

        for (const routeKey of routeKeys) {
          triggerSyncStreamEvent(routeKey, streamPayload as SyncRouteStreamEvent);
        }
        return;
      }

      if (status === "error") {
        if (errorCode === 'sync.ignore' || message === 'sync.ignore') {
          return;
        }
        if (shouldNotifyDev) {
          if (errorCode) {
            notify.error({ key: errorCode, params: errorParams });
          } else if (message) {
            notify.error({ key: message });
          }
        }
        return;
      }

      if (routeKeys.length === 0) {
        const errorMessage = `Sync response is missing fullName for cb '${cb ?? 'unknown'}'.`;
        if (shouldLogDev) {
          console.error(errorMessage);
        }
        if (shouldNotifyDev) {
          notify.error({ key: 'sync.invalidRequestFormat' });
        }
        throw new Error(errorMessage);
      }

      for (const routeKey of routeKeys) {
        triggerSyncEvent(routeKey, clientOutput, serverOutput);
      }
    });


    const handleOnline = () => {
      if (socketConnection.connected) {
        flushApiQueue(canFlushQueue, socketConnection);
        flushSyncQueue(canFlushQueue, socketConnection);
        return;
      }
      socketConnection.connect();
    };

    globalThis.addEventListener("online", handleOnline);

    return () => {
      if (socket) {
        socket.disconnect();
        setSocket(null);
        setDisconnectedStatus(setSocketStatus);
      }

      document.removeEventListener("visibilitychange", handleVisibility)
      globalThis.removeEventListener("online", handleOnline)
    };

  }, [setSocketStatus, triggerSyncEvent, triggerSyncStreamEvent]);

  return socket;
}


// `waitForSocket` moved to @luckystack/core/socketState — re-exported at the
// top of this file to keep the existing symbol visible to callers.

export const joinRoom = async (group: string) => {
  return new Promise<{ success: true; rooms: string[] } | null>((resolve) => {
    void (async () => {
      if (!group || typeof group !== "string") {
        if (shouldLogDev) {
          console.error("Invalid group");
        }
        if (shouldNotifyDev) {
          notify.error({ key: 'common.invalidGroup' });
        }
        resolve(null);
        return;
      }

      if (!await waitForSocket()) {
        resolve(null);
        return;
      }
      if (!socket) {
        resolve(null);
        return;
      }

      const tempIndex = incrementResponseIndex();
      socket.emit(socketEventNames.joinRoom, { group, responseIndex: tempIndex });

      socket.once(buildJoinRoomResponseEventName(tempIndex), (response?: { error?: string; rooms?: unknown }) => {
        if (response?.error) {
          if (shouldLogDev) {
            console.error(response.error);
          }
          if (shouldNotifyDev) {
            notify.error({ key: response.error });
          }
          resolve(null);
          return;
        }

        const rooms = Array.isArray(response?.rooms)
          ? response.rooms.filter((room): room is string => typeof room === 'string')
          : [];

        resolve({ success: true, rooms });
      });
    })();
  });
}

export const leaveRoom = async (group: string) => {
  return new Promise<{ success: true; rooms: string[] } | null>((resolve) => {
    void (async () => {
      if (!group || typeof group !== "string") {
        if (shouldLogDev) {
          console.error("Invalid group");
        }
        if (shouldNotifyDev) {
          notify.error({ key: 'common.invalidGroup' });
        }
        resolve(null);
        return;
      }

      if (!await waitForSocket()) {
        resolve(null);
        return;
      }
      if (!socket) {
        resolve(null);
        return;
      }

      const tempIndex = incrementResponseIndex();
      socket.emit(socketEventNames.leaveRoom, { group, responseIndex: tempIndex });

      socket.once(buildLeaveRoomResponseEventName(tempIndex), (response?: { error?: string; rooms?: unknown }) => {
        if (response?.error) {
          if (shouldLogDev) {
            console.error(response.error);
          }
          if (shouldNotifyDev) {
            notify.error({ key: response.error });
          }
          resolve(null);
          return;
        }

        const rooms = Array.isArray(response?.rooms)
          ? response.rooms.filter((room): room is string => typeof room === 'string')
          : [];

        resolve({ success: true, rooms });
      });
    })();
  });
}

export const getJoinedRooms = async () => {
  return new Promise<string[] | null>((resolve) => {
    void (async () => {
      if (!await waitForSocket()) {
        resolve(null);
        return;
      }
      if (!socket) {
        resolve(null);
        return;
      }

      const tempIndex = incrementResponseIndex();
      socket.emit(socketEventNames.getJoinedRooms, { responseIndex: tempIndex });

      socket.once(buildGetJoinedRoomsResponseEventName(tempIndex), (response?: { error?: string; rooms?: unknown }) => {
        if (response?.error) {
          if (shouldLogDev) {
            console.error(response.error);
          }
          if (shouldNotifyDev) {
            notify.error({ key: response.error });
          }
          resolve(null);
          return;
        }

        const rooms = Array.isArray(response?.rooms)
          ? response.rooms.filter((room): room is string => typeof room === 'string')
          : [];

        resolve(rooms);
      });
    })();
  });
}

export const updateLocationRequest = async ({ location }: { location: { pathName: string, searchParams: Record<string, string> } }) => {
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- this guard is required because deployments can toggle locationProviderEnabled
  if (!isLocationProviderEnabled) { return null; }

  if (!location.pathName) {
    if (shouldLogDev) {
      console.error("Invalid location");
    }
    if (shouldNotifyDev) {
      notify.error({ key: 'common.invalidLocation' });
    }
    return null;
  }

  if (!await waitForSocket()) { return null; }
  if (!socket) { return null; }

  socket.emit(socketEventNames.updateLocation, location);
  return null;
}