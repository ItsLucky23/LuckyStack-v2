export const onLocationChangePlaceholder = 'onLocationChange';
